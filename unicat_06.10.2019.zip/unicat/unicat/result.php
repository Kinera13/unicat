<?php
	ini_set ("display_errors", "1"); 
	error_reporting(E_ALL);
	#require_once'result_html.php';
	/*$db = new mysqli('127.0.0.1', 'mysql', 'mysql', 'psychology') or die('Could not connect'); 
	#$problem = ($_POST['problem']);
	$result = $mysql->query("SELECT `name` FROM `specialist` JOIN `relation` USING (`id_specialist`) WHERE `id_specialist`=5");
	$user = $result->fetch_assoc();
	var_dump($result);
	$result->close();
	exit();*/
	$link = mysqli_connect("127.0.0.1", "mysql", "mysql", "psychology");

/*if (!$link) {
    echo "Ошибка: Невозможно установить соединение с MySQL." . PHP_EOL;
    echo "Код ошибки errno: " . mysqli_connect_errno() . PHP_EOL;
    echo "Текст ошибки error: " . mysqli_connect_error() . PHP_EOL;
    exit;
}
else {
	echo "Сработало!<br>";
}*/
$problem = filter_var(trim($_POST['problem']), FILTER_SANITIZE_STRING);
$result = mysqli_query($link, "SELECT `header`, `id_problem` FROM `relation` JOIN `problem` USING (`id_problem`) JOIN `specialist` WHERE `header`='$problem'");
$result2 = mysqli_query($link, "SELECT `name`, `header` FROM `relation` JOIN `specialist` USING (`id_specialist`) JOIN `problem` USING (`id_problem`) WHERE `header`='$problem'");
$result3 = mysqli_query($link, "SELECT `id_image`, `header` FROM `specialist` JOIN `image` USING (`id_image`) WHERE");
while ($row=mysqli_fetch_assoc($result2)){
$name=$row['name'];
$result3 = mysqli_query($link, "SELECT `id_image`, `header` FROM `specialist` JOIN `images` USING (`id_image`) WHERE `name`='$name'");
$row2=mysqli_fetch_assoc($result3);
print_r ('<p>'.$row['name'].'</p>');

echo'<img src="images/'.$row2['header'].'"><br>';
echo'<input type="button" value="Подробнее">';
}